class Mensagens{
    mensagemErroLogin1 = "Email ou senha incorretos!"
    mensagemErroCadastro2 = "O nome não pode conter números ou símbolos"
    mensagemErroCadastro3 = "o sobrenome nome está inválido"
    mensagemErroCadastro4 = "o email está inválido"
    mensagemErroCadastro5 = "o usuario digitou a senha vazia ou menor que 8 dígitos"
    mensagemErroCadastro6 = "o cpf está inválido"
    mensagemErroCadastro7 = "a rua está inválida"
    mensagemErroCadastro8 = "o numero está inválido"
    mensagemErroCadastro9 = "bairro está inválido"
    mensagemErroCadastro10 = "a cidade está inválida"
    mensagemErroCadastro11 = "o estado está inválido"
    mensagemErroCadastro12 = "o cep está inválido"

    mensagemErroCPF = "Falha ao tentar realizar o cadastro. O cpf informado já foi cadastrado!"
    mensagemErroEMAIL = "Falha ao cadastrar. o Email informado já está sendo utilizado!"

}

module.exports = Mensagens